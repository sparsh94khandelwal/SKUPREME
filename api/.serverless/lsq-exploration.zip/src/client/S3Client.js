"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var S3Handler_1 = require("../S3/S3Handler");
var S3Client = /** @class */ (function () {
    function S3Client(provideId, orgId) {
        this.provideId = provideId;
        this.orgId = orgId;
    }
    S3Client.prototype.s3Put = function (key, logJSON, bucket) {
        key = this.provideId + "/" + this.orgId + "/" + key.trim();
        console.log(bucket, key, logJSON);
        var s3Handler = new S3Handler_1.S3Handler();
        return s3Handler.upload({
            Bucket: bucket,
            Key: key + ".json",
            Body: Buffer.from(JSON.stringify(logJSON)),
            ContentEncoding: "UTF-8",
            ContentType: "application/json"
        });
    };
    S3Client.prototype.s3Get = function (key, bucket) {
        key = this.provideId + "/" + this.orgId + "/" + key.trim();
        var s3Handler = new S3Handler_1.S3Handler();
        return s3Handler.fetch({
            Bucket: bucket,
            Key: key + ".json"
        });
    };
    S3Client.prototype.s3ListObjects = function (bucket) {
        var s3Handler = new S3Handler_1.S3Handler();
        return s3Handler.getObjects({
            Bucket: bucket
        });
    };
    S3Client.getInstance = function (providerId, orgId) {
        if (providerId && orgId) {
            return new S3Client(providerId, orgId);
        }
        throw new Error("Missing Params: Required ProviderId or OrgShortCode are not passed!");
    };
    return S3Client;
}());
exports.default = S3Client;
//# sourceMappingURL=S3Client.js.map