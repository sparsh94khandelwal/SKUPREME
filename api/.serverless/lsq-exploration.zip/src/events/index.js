"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ReportsHandler_1 = require("./ReportsHandler");
Object.defineProperty(exports, "ReportsHandler", { enumerable: true, get: function () { return ReportsHandler_1.ReportsHandler; } });
//# sourceMappingURL=index.js.map